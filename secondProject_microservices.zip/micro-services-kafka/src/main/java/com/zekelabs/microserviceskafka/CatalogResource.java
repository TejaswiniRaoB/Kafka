package com.zekelabs.microserviceskafka;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
//import com.zekelabs.util.ReadExcelFile;

@RestController
@RequestMapping("/catalog")
public class CatalogResource {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    WebClient.Builder webClientBuilder;
    
    @Autowired
	private KafkaTemplate<Object, Object> template;

	@GetMapping(path = "/send")
	public void sendFoo() {
		String csvFile = "/home/edyoda/Downloads/Online_Retail1.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        RecordMetadata metadata = null;
        int index=0;
        try {
        br = new BufferedReader(new FileReader(csvFile));
        while ((line = br.readLine()) != null) {
index++;
String[] country = line.split(cvsSplitBy);
//System.out.println("country"+("United Kingdom".equalsIgnoreCase(country[7])? IKafkaConstants.TOPIC_NAME_UK:("France".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_FRANCE:("Australia".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Australia:("Netherlands".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Netherlands:("EIRE".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Eire: IKafkaConstants.TOPIC_NAME))))));
			this.template.send(("United Kingdom".equalsIgnoreCase(country[7])? IKafkaConstants.TOPIC_NAME_UK:("France".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_FRANCE:("Australia".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Australia:("Netherlands".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Netherlands:("EIRE".equalsIgnoreCase(country[7])?IKafkaConstants.TOPIC_NAME_Eire: IKafkaConstants.TOPIC_NAME))))) , line);
	}
	}catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        if (br != null) {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
	
	}    
}