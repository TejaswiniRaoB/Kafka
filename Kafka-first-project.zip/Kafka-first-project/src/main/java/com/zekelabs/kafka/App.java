package com.zekelabs.kafka;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;

import com.zekelabs.kafka.constants.IKafkaConstants;
import com.zekelabs.kafka.consumer.ConsumerCreator;
import com.zekelabs.kafka.pojo.CustomObject;
import com.zekelabs.kafka.producer.ProducerCreator;

public class App {
	public static void main(String[] args) {
        runProducer();
		runConsumer();
	}

	static void runConsumer() {
		Consumer<Long, CustomObject> consumer = ConsumerCreator.createConsumer();

		int noMessageToFetch = 0;

		while (true) {
			final ConsumerRecords<Long, CustomObject> consumerRecords = consumer.poll(1000);
			
			if (consumerRecords.count() == 0) {
				noMessageToFetch++;
				if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
					break;
				else
					continue;
			}

			consumerRecords.forEach(record -> {
				System.out.println("Record Key " + record.key());
				System.out.println("Record value " + record.value().getId());
				System.out.println("Record value " + record.value().getName());
				System.out.println("Record value " + record.value().getRow());
				System.out.println("Record partition " + record.partition());
				System.out.println("Record offset " + record.offset());
			});
			consumer.commitAsync();
		}
		consumer.close();
	}

	
	static void runProducer() {
		Producer<Long, CustomObject> producer = ProducerCreator.createProducer();
		String csvFile = "/home/edyoda/Downloads/Online_Retail1.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        RecordMetadata metadata = null;
        int index=0;
        
        
        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {
index++;
                // use comma as separator
                String[] country = line.split(cvsSplitBy);
System.out.println("sizeee"+country.length);
                CustomObject c = new CustomObject();
                c.setId(index+"");
                c.setName(country[7]);
                c.setRow(line);
               
           try {
		   
                if(country[7].equalsIgnoreCase("United Kingdom")) {
			final ProducerRecord<Long, CustomObject> recordUK = new ProducerRecord<Long, CustomObject>(IKafkaConstants.TOPIC_NAME_UK,c);
			 metadata = producer.send(recordUK).get();
						
						  System.out.println("Record sent with key " + index + " to partition " +
						  metadata.partition() + " with offset " + metadata.offset());
						 
                }else if(country[7].equalsIgnoreCase("France")){
			
                	final ProducerRecord<Long, CustomObject> recordFRANCE = new ProducerRecord<Long, CustomObject>(IKafkaConstants.TOPIC_NAME_FRANCE,c);
                
                	 metadata = producer.send(recordFRANCE).get();
						
						  System.out.println("Record sent with key " + index + " to partition " +
						  metadata.partition() + " with offset " + metadata.offset());
						 
           }else if(country[7].equalsIgnoreCase("EIRE")){
   			
           	final ProducerRecord<Long, CustomObject> recordEire = new ProducerRecord<Long, CustomObject>(IKafkaConstants.TOPIC_NAME_Eire,c);
           
           	 metadata = producer.send(recordEire).get();
						
						  System.out.println("Record sent with key " + index + " to partition " +
						  metadata.partition() + " with offset " + metadata.offset());
						 
      }else if(country[7].equalsIgnoreCase("Netherlands")){
 			
         	final ProducerRecord<Long, CustomObject> recordNetherlands = new ProducerRecord<Long, CustomObject>(IKafkaConstants.TOPIC_NAME_Netherlands,c);
         
         	 metadata = producer.send(recordNetherlands).get();
						
						  System.out.println("Record sent with key " + index + " to partition " +
						  metadata.partition() + " with offset " + metadata.offset());
						 	
    }else if(country[7].equalsIgnoreCase("Australia")){
			
       	final ProducerRecord<Long, CustomObject> recordAustralia = new ProducerRecord<Long, CustomObject>(IKafkaConstants.TOPIC_NAME_Australia,c);
       
       	 metadata = producer.send(recordAustralia).get();
						
						  System.out.println("Record sent with key " + index + " to partition " +
						  metadata.partition() + " with offset " + metadata.offset());
						 	
  }
                
           }catch (ExecutionException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			} catch (InterruptedException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			}
            
            }
	}catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        if (br != null) {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
}
