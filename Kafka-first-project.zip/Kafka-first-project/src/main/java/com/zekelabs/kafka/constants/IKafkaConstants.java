package com.zekelabs.kafka.constants;

import java.util.Arrays;
import java.util.List;

public interface IKafkaConstants {
	public static String KAFKA_BROKERS = "localhost:9092";
	
	public static Integer MESSAGE_COUNT=100;
	
	public static String CLIENT_ID="client1";
	
	public static String TOPIC_NAME="test";
	
	public static String TOPIC_NAME_UK="UnitedKingdom1";
	
	public static String TOPIC_NAME_FRANCE="France1";
	
	public static String TOPIC_NAME_Eire="Eire1";
	
	public static String TOPIC_NAME_Netherlands="Netherlands1";
	
	public static String TOPIC_NAME_Australia="Australia1";
	
	public static String GROUP_ID_CONFIG="consumerGroup10";
	
	public static Integer MAX_NO_MESSAGE_FOUND_COUNT=100;
	
	public static String OFFSET_RESET_LATEST="latest";
	
	public static String OFFSET_RESET_EARLIER="earliest";
	
	public static Integer MAX_POLL_RECORDS=1;
	
	//public static  List<String> AllTopics =  Arrays.asList(TOPIC_NAME_UK,TOPIC_NAME_FRANCE,TOPIC_NAME_Eire,TOPIC_NAME_Netherlands,TOPIC_NAME_Australia);
}
