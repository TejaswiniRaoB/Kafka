import java.util.*;
import org.apache.kafka.clients.consumer.*;


public class AvroConsumer{    
    
    public static void main(String[] args) throws Exception{

        String topicName = "TopicV1";
            
        String groupName = "RG9";
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092,localhost:9093");
        props.put("group.id", groupName);
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer");
        props.put("schema.registry.url", "http://localhost:8081");
        props.put("specific.avro.reader", "true");
        
        KafkaConsumer<String, RetailRecord> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(topicName));
        try{
            while (true){
                ConsumerRecords<String, RetailRecord> records = consumer.poll(100);
                for (ConsumerRecord<String, RetailRecord> record : records){
                        System.out.println("Description="+ record.value().getDescription()
                                         + " Quantity=" + record.value().getQuantity() 
                                         + " UnitPrice=" + record.value().getUnitPrice());
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
            finally{
                consumer.close();
            }
    }
    
}
